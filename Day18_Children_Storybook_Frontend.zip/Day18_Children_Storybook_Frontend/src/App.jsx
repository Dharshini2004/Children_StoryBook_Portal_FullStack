import React from 'react';
import { useState } from 'react';
import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import './App.css';
import Navbar from './components/Navbar/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import About from './pages/About';
import Contact from './pages/Contact';

import Policy from './pages/Policy';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Carousalcomp from './components/Carouselcomp';
import PictureBooks from './pages/categories/PictureBook/PictureBooks';
import BookDetails from './components/BookDetails';
import { Provider } from 'react-redux';
import { store } from './store';
import CartContainer from './components/cartcomponent/CartContainer';
import PaymentPage from './feature/payment/PaymentPage';
import AdminPanel from './components/dashboard/admin/AdminPanel';
import UserPanel from './components/dashboard/user/UserPanel';
import PaymentSuccess from './pages/PaymentSuccess';
import Privateroute from './components/PrivateRoute';
import Sidebar from './components/admin/Sidebar';
import AddBookPage from './pages/admin/AddBookPage';
import UpdateBookPage from './pages/admin/UpdateBookPage';
import ManageUsersPage from './pages/admin/ManageUsersPage';
import StoryPage from './pages/admin/StoryPage';
import FeedbackPage from './pages/admin/FeedbackPage';
import RazorpayComp from './components/RazorpayComp';
import ManageStoryPage from './pages/admin/ManageStoryPage';


function App() {
  const [books, setBooks] = useState([]);
  const [users, setUsers] = useState([]);

  const handleAddBook = (book) => {
    setBooks([...books, { ...book, id: books.length + 1 }]);
  };

  const handleUpdateBook = (updatedBook) => {
    setBooks(books.map((book) => (book.id === updatedBook.id ? updatedBook : book)));
  };

  const handleDeleteBook = (id) => {
    setBooks(books.filter((book) => book.id !== id));
  };

  const handleDeleteUser = (id) => {
    setUsers(users.filter((user) => user.id !== id));
  };

  return (
    <Provider store={store}>
      {/* <RazorpayComp /> */}
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navbar />}>
            <Route index element={<Login />} />
            <Route index element={<Carousalcomp />} />
            <Route path="/register" element={<Register />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            {/* <Route path="/feedback" element={<Feedback />} /> */}
            <Route path="/policy" element={<Policy />} />
            <Route path="/picturebook" element={<PictureBooks />} />
            <Route path="/book/:id" element={<BookDetails />} />
            <Route path="/cart" element={<CartContainer />} />
            <Route path="/paymentpage" element={<PaymentPage />} />
            <Route path="/user" element={<UserPanel />} />
          {/* <Route path="/home" element={<Privateroute />}> */}
            <Route path='/home' element={<Home />} />
          {/* </Route> */}
          </Route>
          <Route path="/payment" element={<RazorpayComp />} />
          <Route path="/success" element={<PaymentSuccess />} />
          {/* admin */}
          <Route path="/admin" element={< AdminPanel/>}/>
            <Route path="/books" element={<AddBookPage onAddBook={handleAddBook} />} />
            <Route path="/update-book/:id" element={<UpdateBookPage books={books} onUpdateBook={handleUpdateBook} />} />
            <Route path="/users" element={<ManageUsersPage users={users} onDeleteUser={handleDeleteUser} />} />
            <Route path='/story' element={<StoryPage/>}/>
            <Route path="/addquiz" element={<ManageStoryPage />} />
            <Route path='/feedbackadmin' element={<FeedbackPage/>}/>
          
        </Routes>
      </BrowserRouter>
    </Provider>
  );
}

export default App;
