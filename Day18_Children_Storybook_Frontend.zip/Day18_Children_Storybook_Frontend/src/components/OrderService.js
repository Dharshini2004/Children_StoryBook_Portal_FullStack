import axios from 'axios';

const API_URL = 'http://localhost:8080/api/order';

export const createOrder = async (orderData) => {
  const token = localStorage.getItem('token'); // Assuming token is used for auth
  try {
    const response = await axios.post(API_URL + '/add', orderData, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error creating order:', error);
    throw error;
  }
};
