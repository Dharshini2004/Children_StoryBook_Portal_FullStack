import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Container } from '@mui/material';

const QuizTable = ({ storyId }) => {
  const [quizzes, setQuizzes] = useState([]);

  useEffect(() => {
    const fetchQuizzes = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`http://localhost:8080/api/quiz/get`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setQuizzes(response.data);
      } catch (error) {
        console.error('Error fetching quizzes:', error);
      }
    };

    fetchQuizzes();
  }, [storyId]);

  const handleDeleteQuiz = async (quizId) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8080/api/quiz/delete/${quizId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setQuizzes(quizzes.filter(quiz => quiz.questionId !== quizId));
    } catch (error) {
      console.error('Error deleting quiz:', error);
    }
  };

  return (
    <Container>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Question</TableCell>
              <TableCell>Option A</TableCell>
              <TableCell>Option B</TableCell>
              <TableCell>Option C</TableCell>
              <TableCell>Option D</TableCell>
              <TableCell>Answer</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {quizzes.map(quiz => (
              <TableRow key={quiz.questionId}>
                <TableCell>{quiz.question}</TableCell>
                <TableCell>{quiz.optionA}</TableCell>
                <TableCell>{quiz.optionB}</TableCell>
                <TableCell>{quiz.optionC}</TableCell>
                <TableCell>{quiz.optionD}</TableCell>
                <TableCell>{quiz.answer}</TableCell>
                <TableCell>
                  <Button variant="contained" color="secondary" onClick={() => handleDeleteQuiz(quiz.questionId)}>Delete</Button>
                  <Button variant="contained" color="primary" onClick={() => {/* Add Update Functionality Here */}}>Update</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
};

export default QuizTable;
