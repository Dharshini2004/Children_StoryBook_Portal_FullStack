import React, { useState, useEffect } from 'react';
import { Box, TextField, Button, Typography } from '@mui/material';

const UserForm = ({ onSubmit, user }) => {
  const [name, setName] = useState(user ? user.name : '');
  const [email, setEmail] = useState(user ? user.email : '');
  const [password, setPassword] = useState('');

  useEffect(() => {
    if (user) {
      setName(user.name);
      setEmail(user.email);
      setPassword(''); // Clear password when editing
    } else {
      setName('');
      setEmail('');
      setPassword('');
    }
  }, [user]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      userId: user ? user.userId : null,  // Include userId if updating
      name,
      email,
      password, // Include password for new users
    });
    setName('');
    setEmail('');
    setPassword('');
  };

  return (
    <Box component="form" onSubmit={handleSubmit} p={3}>
      <Typography variant="h5">{user ? 'Update User' : 'Add User'}</Typography>
      <TextField
        label="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        fullWidth
        margin="normal"
        required
      />
      <TextField
        label="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        fullWidth
        margin="normal"
        type="email"
        required
      />
      {!user && (
        <TextField
          label="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          fullWidth
          margin="normal"
          type="password"
          required
        />
      )}
      <Box mt={3}>
        <Button type="submit" variant="contained" color="primary">
          {user ? 'Update User' : 'Add User'}
        </Button>
      </Box>
    </Box>
  );
};

export default UserForm;




// import React, { useState, useEffect } from 'react';
// import { Box, TextField, Button, Typography } from '@mui/material';

// const UserForm = ({ onSubmit, user }) => {
//   const [name, setName] = useState(user ? user.name : '');
//   const [email, setEmail] = useState(user ? user.email : '');

//   useEffect(() => {
//     if (user) {
//       setName(user.name);
//       setEmail(user.email);
//     }
//   }, [user]);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     onSubmit({ id: user ? user.id : null, name, email });
//     setName('');
//     setEmail('');
//   };

//   return (
//     <Box component="form" onSubmit={handleSubmit} p={3}>
//       <Typography variant="h5">{user ? 'Update User' : 'Add User'}</Typography>
//       <TextField
//         label="Name"
//         value={name}
//         onChange={(e) => setName(e.target.value)}
//         fullWidth
//         margin="normal"
//       />
//       <TextField
//         label="Email"
//         value={email}
//         onChange={(e) => setEmail(e.target.value)}
//         fullWidth
//         margin="normal"
//       />
//       <Button type="submit" variant="contained" color="primary">
//         {user ? 'Update User' : 'Add User'}
//       </Button>
//     </Box>
//   );
// };

// export default UserForm;
