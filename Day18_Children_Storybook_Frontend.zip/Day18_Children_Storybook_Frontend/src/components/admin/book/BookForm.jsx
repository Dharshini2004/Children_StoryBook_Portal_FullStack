import React, { useState, useEffect } from 'react';
import { Box, TextField, Button, Typography } from '@mui/material';

const BookForm = ({ onSubmit, book }) => {
  const [title, setTitle] = useState(book ? book.title : '');
  const [author, setAuthor] = useState(book ? book.author : '');
  const [publisher, setPublisher] = useState(book ? book.publisher : '');
  const [grade, setGrade] = useState(book ? book.grade : '');
  const [price, setPrice] = useState(book ? book.price : '');
  const [genre, setGenre] = useState(book ? book.genre : '');
  const [imageurl, setImageurl] = useState(book ? book.imageurl : '');
  const [videourl, setVideourl] = useState(book ? book.videourl : '');
  const [description, setDescription] = useState(book ? book.description : '');

  useEffect(() => {
    if (book) {
      setTitle(book.title);
      setAuthor(book.author);
      setPublisher(book.publisher);
      setGrade(book.grade);
      setPrice(book.price);
      setGenre(book.genre);
      setImageurl(book.imageurl);
      setVideourl(book.videourl);
      setDescription(book.description);
    }
  }, [book]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      bookId: book ? book.bookId : null,  // Include bookId if updating
      title,
      author,
      publisher,
      grade,
      price,
      genre,
      imageurl,
      videourl,
      description,
    });
    setTitle('');
    setAuthor('');
    setPublisher('');
    setGrade('');
    setPrice('');
    setGenre('');
    setImageurl('');
    setVideourl('');
    setDescription('');
  };

  return (
    <Box component="form" onSubmit={handleSubmit} p={3}>
      <Typography variant="h5">{book ? 'Update Book' : 'Add Book'}</Typography>
      <TextField
        label="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        fullWidth
        margin="normal"
        required
      />
      <TextField
        label="Author"
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
        fullWidth
        margin="normal"
        required
      />
      <TextField
        label="Publisher"
        value={publisher}
        onChange={(e) => setPublisher(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Grade"
        value={grade}
        onChange={(e) => setGrade(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Price"
        value={price}
        onChange={(e) => setPrice(e.target.value)}
        fullWidth
        margin="normal"
        type="number"
      />
      <TextField
        label="Genre"
        value={genre}
        onChange={(e) => setGenre(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Image URL"
        value={imageurl}
        onChange={(e) => setImageurl(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Video URL"
        value={videourl}
        onChange={(e) => setVideourl(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        fullWidth
        margin="normal"
        multiline
        rows={4}
      />
      <Box mt={3}>
        <Button type="submit" variant="contained" color="primary">
          {book ? 'Update Book' : 'Add Book'}
        </Button>
      </Box>
    </Box>
  );
};

export default BookForm;



