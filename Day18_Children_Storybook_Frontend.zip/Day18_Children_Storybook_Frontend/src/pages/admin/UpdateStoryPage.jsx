import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import StoryForm from '../../components/admin/story/StoryForm';
import axios from 'axios';

const UpdateStoryPage = ({ onUpdateStory }) => {
  const { id } = useParams();
  const [story, setStory] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStory = async () => {
      const token = localStorage.getItem('token');
      try {
        const response = await axios.get(`http://localhost:8080/api/story/get/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setStory(response.data);
      } catch (err) {
        setError('Failed to fetch story details.');
        console.error('Error fetching story:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchStory();
  }, [id]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  if (!story) {
    return <div>Story not found.</div>;
  }

  return <StoryForm onSubmit={onUpdateStory} story={story} />;
};

export default UpdateStoryPage;
