import React from 'react';
import AddQuizPage from './AddQuizPage';
import QuizTable from '../../components/admin/quiz/QuizTable';

const ManageStoryPage = ({ storyId }) => {
  return (
    <>
      <AddQuizPage storyId={storyId} />
      <QuizTable storyId={storyId} />
    </>
  );
};

export default ManageStoryPage;
