import React, { useState } from 'react';
import axios from 'axios';
import { Button, TextField, Container, Typography } from '@mui/material';

const AddQuizPage = ({ storyId }) => {
  const [question, setQuestion] = useState('');
  const [optionA, setOptionA] = useState('');
  const [optionB, setOptionB] = useState('');
  const [optionC, setOptionC] = useState('');
  const [optionD, setOptionD] = useState('');
  const [answer, setAnswer] = useState('');

  const handleAddQuiz = async () => {
    try {
      const token = localStorage.getItem('token');
      const newQuiz = {
        question,
        optionA,
        optionB,
        optionC,
        optionD,
        answer,
        story_id: storyId,
      };
      await axios.post('http://localhost:8080/api/quiz/add', newQuiz, {
        headers: { Authorization: `Bearer ${token}` },
      });
      // Reset form
      setQuestion('');
      setOptionA('');
      setOptionB('');
      setOptionC('');
      setOptionD('');
      setAnswer('');
    } catch (error) {
      console.error('Error adding quiz:', error);
    }
  };

  return (
    <Container>
      <Typography variant="h4" gutterBottom>Add New Quiz</Typography>
      <TextField label="Question" fullWidth margin="normal" value={question} onChange={(e) => setQuestion(e.target.value)} />
      <TextField label="Option A" fullWidth margin="normal" value={optionA} onChange={(e) => setOptionA(e.target.value)} />
      <TextField label="Option B" fullWidth margin="normal" value={optionB} onChange={(e) => setOptionB(e.target.value)} />
      <TextField label="Option C" fullWidth margin="normal" value={optionC} onChange={(e) => setOptionC(e.target.value)} />
      <TextField label="Option D" fullWidth margin="normal" value={optionD} onChange={(e) => setOptionD(e.target.value)} />
      <TextField label="Answer" fullWidth margin="normal" value={answer} onChange={(e) => setAnswer(e.target.value)} />
      <Button variant="contained" color="primary" onClick={handleAddQuiz}>Add Quiz</Button>
    </Container>
  );
};

export default AddQuizPage;
