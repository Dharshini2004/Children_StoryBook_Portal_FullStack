import React, { useState, useEffect } from 'react';
import { Box, Button, Typography, Modal } from '@mui/material';
import BookForm from '../../components/admin/book/BookForm';
import BookTable from '../../components/admin/book/BookTable';
import Sidebar from '../../components/admin/Sidebar';
import axios from 'axios';

const AddBooksPage = () => {
  const [books, setBooks] = useState([]);
  const [currentBook, setCurrentBook] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Fetch books from the database when the component mounts
  useEffect(() => {
    const fetchBooks = async () => {
      const token = localStorage.getItem('token');

      try {
        const response = await axios.get('http://localhost:8080/api/books/get', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setBooks(response.data);
      } catch (error) {
        console.error('Error fetching books:', error);
        alert('Failed to fetch books.');
      }
    };

    fetchBooks();
  }, []);

  const handleAddBook = async (book) => {
    const token = localStorage.getItem('token');

    try {
      let response;
      if (book.bookId) {
        // Update existing book
        response = await axios.put(`http://localhost:8080/api/books/put/${book.bookId}`, book, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setBooks(books.map((b) => (b.bookId === book.bookId ? response.data : b)));
      } else {
        // Add new book
        response = await axios.post('http://localhost:8080/api/books/add', book, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setBooks([...books, response.data]);
      }
    } catch (error) {
      console.error('Error adding/updating book:', error);
      alert('Failed to add/update book.');
    }

    setIsModalOpen(false);
  };

  const handleEditBook = (book) => {
    setCurrentBook(book);
    setIsModalOpen(true);
  };

  const handleDeleteBook = async (bookId) => {
    const token = localStorage.getItem('token');

    try {
      await axios.delete(`http://localhost:8080/api/books/delete/${bookId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setBooks(books.filter((book) => book.bookId !== bookId));
    } catch (error) {
      console.error('Error deleting book:', error);
      alert('Failed to delete book.');
    }
  };

  const handleAddNewBook = () => {
    setCurrentBook(null);
    setIsModalOpen(true);
  };

  return (
    <>
      <Sidebar />
      <Box sx={{ display: 'flex', flexDirection: 'column', marginLeft: { xs: 0, md: '240px' }, p: 3 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <Typography variant="h4">Books</Typography>
          <Button variant="contained" color="primary" onClick={handleAddNewBook}>
            Add Book
          </Button>
        </Box>
        <BookTable onEdit={handleEditBook} onDelete={handleDeleteBook} books={books} />
        <Modal open={isModalOpen} onClose={() => setIsModalOpen(false)}>
          <Box
            position="absolute"
            top="10%"
            left="10%"
            right="10%"
            bottom="10%"
            overflow="auto"
            bgcolor="background.paper"
            boxShadow={24}
            p={4}
            borderRadius={2}
          >
            <BookForm onSubmit={handleAddBook} book={currentBook} />
          </Box>
        </Modal>
      </Box>
    </>
  );
};

export default AddBooksPage;


