package com.example.storybookbackend.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.storybookbackend.Model.Story;
import com.example.storybookbackend.Service.StoryService;

@RestController
public class StoryController {
     @Autowired
    StoryService storyService;

    //post
    @PostMapping("/addstory")
    public ResponseEntity<Story> addStory(@RequestBody Story story)
    {
        Story b=storyService.createStoryDetails(story);
        return new ResponseEntity<>(b,HttpStatus.CREATED);
    }

    //get
    @GetMapping("/getstorydata")
    public ResponseEntity<java.util.List<Story>> showStorydetails()
    {
        return new ResponseEntity<>(storyService.getStoryDetails(),HttpStatus.OK);
    }

    //UPDATE
    @PutMapping("/putstorydata/{id}")
    public ResponseEntity<Story> updateStoryDetails(@PathVariable("id") int id,@RequestBody Story story )
    {   
        if(storyService.updateStoryDetails(id, story)==true)
        {

            return new ResponseEntity<>(story,HttpStatus.OK);
        }
        return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
    }

    //DELETE
    @DeleteMapping("/deletestorydata/{id}")
    public ResponseEntity<Boolean> deleteStorydata(@PathVariable("id") int id)
    {
        if(storyService.deleteStoryDetails(id)==true)
        {
            return new ResponseEntity<>(true,HttpStatus.OK);
        }
        return new ResponseEntity<>(false,HttpStatus.NOT_FOUND);
    }
}
