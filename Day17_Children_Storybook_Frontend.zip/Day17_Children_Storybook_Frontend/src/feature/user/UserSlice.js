import { createSlice } from '@reduxjs/toolkit';
const initialState= {
  username: null,
  isLoggedIn: false,
}

const UserSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    login: (state, action) => {
      state.username = action.payload;
      state.isLoggedIn = true;
    },
    logout: (state) => {
      state.username = null;
      state.isLoggedIn = false;
    },
  },
});

export const { login, logout } = UserSlice.actions;
export default UserSlice.reducer;
