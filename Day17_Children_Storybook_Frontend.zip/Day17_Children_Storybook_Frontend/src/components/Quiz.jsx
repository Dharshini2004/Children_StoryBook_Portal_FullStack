import React, { useState } from 'react';
import { Card, CardContent, Button, Grid, Typography } from '@mui/material';

const Quiz = ({ quiz, quizIndex, checkAnswer, selectedAnswers, showAnswers, handleShowAnswer }) => {
  return (
    <Card sx={{ mt: 3 }}>
      <CardContent>
        <Typography variant="h6">{quiz.question}</Typography>
        <Grid container spacing={2}>
          {quiz.options.map((option, idx) => (
            <Grid item xs={12} sm={6} key={idx}>
              <Button
                variant="contained"
                fullWidth
                onClick={() => checkAnswer(quizIndex, option)}
                sx={{
                  backgroundColor: showAnswers[quizIndex]
                    ? quiz.answer === option
                      ? 'green'
                      : '#d6067c'
                    : selectedAnswers[quizIndex]?.option === option
                      ? selectedAnswers[quizIndex].isCorrect
                        ? 'green'
                        : 'red'
                      : '#d6067c',
                  ':hover': {
                    backgroundColor: showAnswers[quizIndex]
                      ? quiz.answer === option
                        ? 'green'
                        : '#d6067c'
                      : selectedAnswers[quizIndex]?.option === option
                        ? selectedAnswers[quizIndex].isCorrect
                          ? 'green'
                          : 'red'
                        : '#d6067c',
                  }
                }}
              >
                {option}
              </Button>
            </Grid>
          ))}
        </Grid>
        <Button
          variant="outlined"
          onClick={() => handleShowAnswer(quizIndex)}
          sx={{ mt: 2 }}
        >
          See Answer
        </Button>
      </CardContent>
    </Card>
  );
};

export default Quiz;
