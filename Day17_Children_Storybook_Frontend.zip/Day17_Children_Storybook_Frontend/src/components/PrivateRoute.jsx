import React from 'react'
import { Box } from '@mui/material'
import Navbar from './Navbar/Navbar'
import { Navigate, Outlet } from 'react-router-dom'
import { useSelector } from 'react-redux'

function Privateroute() {
  const isLoggedIn = useSelector(state => state.user.isLoggedIn) // Example selector for authentication status

  return (
    <Box>
      {/* <Navbar/> */}
      {isLoggedIn ? <Outlet /> : <Navigate to="/" />}
    </Box>
  )
}

export default Privateroute

