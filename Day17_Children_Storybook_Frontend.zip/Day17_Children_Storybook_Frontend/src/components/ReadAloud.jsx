import React, { useState } from 'react';
import { Button } from '@mui/material';

const ReadAloud = ({ text }) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [utterance, setUtterance] = useState(null);

  const handleReadAloud = () => {
    if (isSpeaking) {
      if (isPaused) {
        speechSynthesis.resume();
        setIsPaused(false);
      } else {
        speechSynthesis.cancel();
        setIsSpeaking(false);
      }
      return;
    }

    const newUtterance = new SpeechSynthesisUtterance(text);
    newUtterance.onend = () => setIsSpeaking(false);
    newUtterance.onerror = () => setIsSpeaking(false);

    speechSynthesis.speak(newUtterance);
    setUtterance(newUtterance);
    setIsSpeaking(true);
    setIsPaused(false);
  };

  const handlePause = () => {
    if (isSpeaking && !isPaused) {
      speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const handleResume = () => {
    if (isSpeaking && isPaused) {
      speechSynthesis.resume();
      setIsPaused(false);
    }
  };

  return (
    <div>
      <Button
        variant="contained"
        onClick={handleReadAloud}
        sx={{ backgroundColor: '#d6067c', '&:hover': { backgroundColor: '#b00566' } }}
      >
        {isSpeaking ? (isPaused ? 'stop' : 'Stop') : 'Read Aloud'}
      </Button>
      {isSpeaking && !isPaused && (
        <Button
          variant="outlined"
          onClick={handlePause}
          sx={{ ml: 2, backgroundColor: '#d6067c', '&:hover': { backgroundColor: '#b00566' } }}
        >
          Pause
        </Button>
      )}
      {isSpeaking && isPaused && (
        <Button
          variant="outlined"
          onClick={handleResume}
          sx={{ ml: 2, backgroundColor: '#d6067c', '&:hover': { backgroundColor: '#b00566' } }}
        >
          Resume
        </Button>
      )}
    </div>
  );
};

export default ReadAloud;
