import React from 'react';
import { useParams } from 'react-router-dom';
import BookForm from '../../components/admin/book/BookForm';


const UpdateBookPage = ({ books, onUpdateBook }) => {
  const { id } = useParams();
  const book = books.find((b) => b.id === parseInt(id));
  return <BookForm onSubmit={onUpdateBook} book={book} />;
};

export default UpdateBookPage;
