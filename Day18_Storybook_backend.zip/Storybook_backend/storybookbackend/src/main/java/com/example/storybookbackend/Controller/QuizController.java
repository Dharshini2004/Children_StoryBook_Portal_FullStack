package com.example.storybookbackend.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.storybookbackend.Model.Quiz;
import com.example.storybookbackend.Model.Story;
import com.example.storybookbackend.Service.QuizService;

@RestController
@RequestMapping("/api/quiz")
public class QuizController {
    @Autowired
    QuizService quizService;

    //post
    @PostMapping("/add")
    public ResponseEntity<Quiz> addQuiz(@RequestBody Quiz quiz)
    {
        Quiz b=quizService.createQuizDetails(quiz);
        return new ResponseEntity<>(b,HttpStatus.CREATED);
    }

    //get
    @GetMapping("/get")
    public ResponseEntity<java.util.List<Quiz>> showQuizdetails()
    {
        return new ResponseEntity<>(quizService.getQuizDetails(),HttpStatus.OK);
    }

    //getbyid
    @GetMapping("/get/{id}")
    public Quiz getQuizById(@PathVariable int id) {
        return quizService.getQuizById(id);
    }

    //UPDATE
    @PutMapping("/put/{id}")
    public ResponseEntity<Quiz> updateQuizDetails(@PathVariable("id") int id,@RequestBody Quiz quiz )
    {   
        if(quizService.updateQuizDetails(id, quiz)==true)
        {

            return new ResponseEntity<>(quiz,HttpStatus.OK);
        }
        return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
    }

    //DELETE
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Boolean> deleteQuizdata(@PathVariable("id") int id)
    {
        if(quizService.deleteQuizDetails(id)==true)
        {
            return new ResponseEntity<>(true,HttpStatus.OK);
        }
        return new ResponseEntity<>(false,HttpStatus.NOT_FOUND);
    }
}
