package com.example.storybookbackend.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.storybookbackend.Model.Story;
import com.example.storybookbackend.Repository.StoryRepo;


@Service
public class StoryService {
    @Autowired
    StoryRepo storyRepo;

    //post and create 
    public Story createStoryDetails(Story story)
    {
        return storyRepo.save(story);
    }

    //get
    public List<Story> getStoryDetails()
    {
        return storyRepo.findAll();
    }

    //get by id
    public Story getStoryById(int id)
    {
        return storyRepo.findById(id).orElse(null);
    }

      //update or put
      public boolean updateStoryDetails(int id,Story story)
      {
          if(this.getStoryById(id)==null)
          {
              return false;
          }
          try{
              storyRepo.save(story);
          }
          catch(Exception e)
          {
              return false;
          }
          return true;
      }

    //delete
    public boolean deleteStoryDetails(int id)
    {
        if(this.getStoryById(id)==null)
        {
            return false;
        }
        storyRepo.deleteById(id);
        return true;
    }
}
