package com.example.storybookbackend.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.storybookbackend.Model.Book;
import com.example.storybookbackend.Model.Story;
import com.example.storybookbackend.Service.BookService;

@RestController
@RequestMapping("/api/books")
public class BookController {
    @Autowired
    BookService bookService;

    //post
    @CrossOrigin(origins = "http://localhost:5173")
    @PostMapping("/add")
    public ResponseEntity<Book> addbook(@RequestBody Book book)
    {
        Book b=bookService.createbBookDetails(book);
        return new ResponseEntity<>(b,HttpStatus.CREATED);
    }

    //get
    @CrossOrigin(origins = "http://localhost:5173")
    @GetMapping("/get")
    public ResponseEntity<java.util.List<Book>> showbookdetails()
    {
        return new ResponseEntity<>(bookService.getBookDetails(),HttpStatus.OK);
    }

    //getbyid
    @CrossOrigin(origins = "http://localhost:5173")
    @GetMapping("/get/{id}")
    public Book getBookById(@PathVariable int id) {
        return bookService.getBookById(id);
    }

    //UPDATE
    @CrossOrigin(origins = "http://localhost:5173")
    @PutMapping("/put/{id}")
    public ResponseEntity<Book> updateUserDetails(@PathVariable("id") int id,@RequestBody Book book )
    {   
        if(bookService.updateBookDetails(id, book)==true)
        {

            return new ResponseEntity<>(book,HttpStatus.OK);
        }
        return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
    }

    //DELETE
    @CrossOrigin(origins = "http://localhost:5173")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Boolean> deleteuserdata(@PathVariable("id") int id)
    {
        if(bookService.deleteBookDetails(id)==true)
        {
            return new ResponseEntity<>(true,HttpStatus.OK);
        }
        return new ResponseEntity<>(false,HttpStatus.NOT_FOUND);
    }
}
