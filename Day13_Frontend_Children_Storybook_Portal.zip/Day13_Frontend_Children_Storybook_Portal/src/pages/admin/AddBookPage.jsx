import React, { useState } from 'react';
import { Box, Button, Typography, Modal } from '@mui/material';
import BookForm from '../../components/admin/book/BookForm';
import BookTable from '../../components/admin/book/BookTable';
import Sidebar from '../../components/admin/Sidebar';


const AddBooksPage = () => {
  const [books, setBooks] = useState([]);
  const [currentBook, setCurrentBook] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleAddBook = (book) => {
    if (book.id) {
      setBooks(books.map((b) => (b.id === book.id ? book : b)));
    } else {
      setBooks([...books, { ...book, id: books.length + 1 }]);
    }
    setIsModalOpen(false);
  };

  const handleEditBook = (book) => {
    setCurrentBook(book);
    setIsModalOpen(true);
  };

  const handleDeleteBook = (id) => {
    setBooks(books.filter((book) => book.id !== id));
  };

  const handleAddNewBook = () => {
    setCurrentBook(null);
    setIsModalOpen(true);
  };

  return (
    <>
    <Sidebar/>
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h4">Books</Typography>
        <Button variant="contained" color="primary" onClick={handleAddNewBook}>
          Add Book
        </Button>
      </Box>
      <BookTable books={books} onEdit={handleEditBook} onDelete={handleDeleteBook} />
      <Modal open={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <Box
          position="absolute"
          top="25%"
          left="25%"
          transform="translate(-50%, -50%)"
          bgcolor="background.paper"
          justifyContent={"center"}
          p={4}
          boxShadow={24}
          borderRadius={2}
        >
          <BookForm onSubmit={handleAddBook} book={currentBook} />
        </Box>
      </Modal>
    </Box>
    </>
  );
};

export default AddBooksPage;
