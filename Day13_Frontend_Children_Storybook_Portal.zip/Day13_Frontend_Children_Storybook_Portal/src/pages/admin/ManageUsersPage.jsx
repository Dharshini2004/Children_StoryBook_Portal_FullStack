import React, { useState } from 'react';
import { Box, Button, Typography, Modal } from '@mui/material';
import UserTable from '../../components/admin/user/UserTable';
import UserForm from '../../components/admin/user/UserForm';
import Sidebar from '../../components/admin/Sidebar';


const ManageUsersPage = () => {
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleAddUser = (user) => {
    if (user.id) {
      setUsers(users.map((u) => (u.id === user.id ? user : u)));
    } else {
      setUsers([...users, { ...user, id: users.length + 1 }]);
    }
    setIsModalOpen(false);
  };

  const handleEditUser = (user) => {
    setCurrentUser(user);
    setIsModalOpen(true);
  };

  const handleDeleteUser = (id) => {
    setUsers(users.filter((user) => user.id !== id));
  };

  const handleAddNewUser = () => {
    setCurrentUser(null);
    setIsModalOpen(true);
  };

  return (
    <>
    <Sidebar/>
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h4">Users</Typography>
        <Button variant="contained" color="primary" onClick={handleAddNewUser}>
          Add User
        </Button>
      </Box>
      <UserTable users={users} onEdit={handleEditUser} onDelete={handleDeleteUser} />
      <Modal open={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <Box
          position="absolute"
          top="25%"
          left="25%"
          transform="translate(-50%, -50%)"
          bgcolor="background.paper"
          p={4}
          boxShadow={24}
          borderRadius={2}
        >
          <UserForm onSubmit={handleAddUser} user={currentUser} />
        </Box>
      </Modal>
    </Box>
    </>
  );
};

export default ManageUsersPage;
