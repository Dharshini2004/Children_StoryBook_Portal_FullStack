import React, { useRef, useState } from 'react';
import { Box, TextField, InputAdornment, Button, Avatar, Typography } from '@mui/material';
import AccountCircle from '@mui/icons-material/AccountCircle';
import PasswordIcon from '@mui/icons-material/Password';
import LockRoundedIcon from '@mui/icons-material/LockRounded';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import axios from 'axios';
import { login } from '../feature/user/UserSlice';

const linearGradient = 'linear-gradient(to right, #f569a3, #f79ed1)';

export default function Login() {

  // Data for backend
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const emailRef = useRef(null);
  const passwordRef = useRef(null);
  const [error, setError] = useState({ email: false, password: false });
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const email = formData.email;
    const password = formData.password;

    try {
      const response = await axios.post(
        'http://localhost:8080/api/auth/login',
        formData
      );
      console.log(response.data);
      const { accessToken, role } = response.data;
      localStorage.setItem('token', accessToken);
      localStorage.setItem('role', role);
      console.log('Token:', localStorage.getItem('token'));
      // alert('Login Success.!');
      if (role === 'ADMIN') {
        navigate('/admin');
      } else {
        navigate('/user');
      }
    } catch (error) {
      console.error(error);
      alert('Invalid Credentials.!');
    }

    if (email && password) {
      setError({ email: false, password: false });
      dispatch(login(nameRef.current.value));
    } else {
      if (!email) setError((prev) => ({ ...prev, email: true }));
      if (!password) setError((prev) => ({ ...prev, password: true }));
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <Box
        display="flex"
        flexDirection="column"
        maxWidth={600}
        minWidth={400}
        alignItems="center"
        justifyContent="center"
        margin="auto"
        marginTop={5}
        padding={3}
        borderRadius={5}
        boxShadow="5px 5px 10px #ccc"
        sx={{
          ':hover': {
            boxShadow: '10px 10px 20px #ccc',
          },
          backgroundImage: linearGradient,
          alignItems: 'center',
          color: 'black',
        }}
      >
        <Avatar id="avatar">
          <LockRoundedIcon />
        </Avatar>
        <Typography variant="h4" padding={3} textAlign="center">
          Login
        </Typography>
        <Box>
          <TextField
            id="input-with-icon-textfield"
            label="Email"
            name="email"
            inputRef={emailRef}
            value={formData.email}
            onChange={handleChange}
            variant="outlined"
            margin="normal"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <AccountCircle />
                </InputAdornment>
              ),
            }}
            error={error.email}
            helperText={error.email ? 'Fill the valid email' : ''}
          />
        </Box>
        <Box>
          <TextField
            id="password-with-icon-textfield"
            label="Password"
            type="password"
            name="password"
            inputRef={passwordRef}
            value={formData.password}
            onChange={handleChange}
            variant="outlined"
            margin="normal"
            fullWidth
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <PasswordIcon />
                </InputAdornment>
              ),
            }}
            error={error.password}
            helperText={error.password ? 'Fill the password' : ''}
          />
        </Box>
        <Button
          sx={{ marginTop: 3, borderRadius: 3, backgroundColor: '#d6067c', ':hover': { backgroundColor: '#ed5192' } }}
          variant="contained"
          type="submit"
        >
          Submit
        </Button>
        <Typography variant="body1" component="span" style={{ marginTop: '10px' }}>
          Not registered yet?{' '}
          <span style={{ color: '#d6067c', cursor: 'pointer' }} onClick={() => navigate('/register')}>
            Register
          </span>
        </Typography>
      </Box>
    </form>
  );
}


