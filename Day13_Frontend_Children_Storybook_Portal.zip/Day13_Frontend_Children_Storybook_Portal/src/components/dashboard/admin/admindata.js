const admindata = {
    acquisition: [
      { name: 'Search engines', value: 400 },
      { name: 'Direct Traffic', value: 300 },
      { name: 'Referral Traffic', value: 300 },
      { name: 'Ad Campaigns', value: 200 },
      { name: 'Other', value: 100 },
    ],
    
  };
  
  export default admindata;
  